"""Packaged asset resolution and Codex skill installation helpers."""
from __future__ import annotations

from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version as package_version
from importlib.resources.abc import Traversable
from importlib.resources import files
from pathlib import Path
from typing import Any
import os
import json
import shutil
import tempfile


ASSET_PACKAGE = "core._assets"
CODEX_INSTALL_PREFIX = "mstack-"
CODEX_MANIFEST = ".mstack-install.json"
CODEX_PLUGIN_MANIFEST = ".mstack-plugin-install.json"
CODEX_SKILL_DIR = "skills-codex"
CLASSIC_SKILL_DIR = "skills"
PRESET_DIR = "presets"
PLUGIN_DIR = "plugins"
PLUGIN_MARKETPLACE_TEMPLATE = "marketplace.template.json"
CODEX_PLUGIN_NAME = "mstack-codex"


def asset_dir(name: str) -> Path:
    """Return a filesystem path for a packaged asset directory."""
    resource = files(ASSET_PACKAGE).joinpath(name)
    return _materialize_dir(resource, name)


def packaged_codex_skill_dirs() -> list[Path]:
    """Return packaged Codex skill directories."""
    root = asset_dir(CODEX_SKILL_DIR)
    return sorted(path for path in root.iterdir() if path.is_dir())


def packaged_codex_plugin_dir(plugin_name: str = CODEX_PLUGIN_NAME) -> Path:
    """Return the packaged plugin bundle directory."""
    root = asset_dir(PLUGIN_DIR)
    plugin_dir = root / plugin_name
    if not plugin_dir.is_dir():
        raise FileNotFoundError(f"Packaged plugin bundle not found: {plugin_name}")
    return plugin_dir


def packaged_codex_plugin_skill_dirs(plugin_name: str = CODEX_PLUGIN_NAME) -> list[Path]:
    """Return the packaged skill directories embedded in a plugin bundle."""
    plugin_dir = packaged_codex_plugin_dir(plugin_name)
    skills_dir = plugin_dir / "skills"
    return sorted(path for path in skills_dir.iterdir() if path.is_dir())


@dataclass(frozen=True)
class CodexInstallResult:
    """Summary of a Codex asset installation run."""

    target_dir: Path
    installed: tuple[str, ...] = ()
    skipped: tuple[str, ...] = ()
    overwritten: tuple[str, ...] = ()


@dataclass(frozen=True)
class CodexPluginInstallResult:
    """Summary of a Codex plugin installation run."""

    target_dir: Path
    plugin_name: str
    skill_count: int
    installed: bool = False
    skipped: bool = False
    overwritten: bool = False
    marketplace_path: Path | None = None
    marketplace_updated: bool = False


def install_codex_skills(
    target_dir: Path,
    *,
    force: bool = False,
    dry_run: bool = False,
) -> CodexInstallResult:
    """Install packaged Codex skills into the target directory."""
    target_dir.mkdir(parents=True, exist_ok=True)
    installed: list[str] = []
    skipped: list[str] = []
    overwritten: list[str] = []
    collisions: list[str] = []

    for src in packaged_codex_skill_dirs():
        dest_name = f"{CODEX_INSTALL_PREFIX}{src.name}"
        dest = target_dir / dest_name

        if dest.exists():
            if _is_managed_codex_skill(dest):
                if force:
                    overwritten.append(dest_name)
                else:
                    skipped.append(dest_name)
                    continue
            else:
                collisions.append(dest_name)
                continue

        if dry_run:
            installed.append(dest_name)
            continue

        if dest.exists() and force:
            shutil.rmtree(dest)

        shutil.copytree(src, dest)
        manifest = {
            "managed_by": "mstack",
            "skill": src.name,
            "installed_name": dest_name,
            "version": _installed_package_version(),
        }
        (dest / CODEX_MANIFEST).write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        installed.append(dest_name)

    if collisions:
        collision_text = ", ".join(sorted(collisions))
        raise FileExistsError(
            f"Target contains unmanaged collisions: {collision_text}. Use a clean target or remove them."
        )

    return CodexInstallResult(
        target_dir=target_dir,
        installed=tuple(installed),
        skipped=tuple(skipped),
        overwritten=tuple(overwritten),
    )


def install_codex_plugin(
    target_dir: Path,
    *,
    force: bool = False,
    dry_run: bool = False,
    with_marketplace: bool = False,
    marketplace_path: Path | None = None,
) -> CodexPluginInstallResult:
    """Install the packaged Codex plugin bundle into the target directory."""
    src = packaged_codex_plugin_dir()
    skill_count = len(packaged_codex_plugin_skill_dirs())
    target_dir = target_dir.expanduser()

    overwritten = False
    skipped = False

    if target_dir.exists():
        if _is_managed_codex_plugin(target_dir):
            if force:
                overwritten = True
            else:
                skipped = True
        else:
            raise FileExistsError(
                f"Target contains unmanaged collisions: {target_dir}. Use a clean target or remove it."
            )

    marketplace_target: Path | None = None
    marketplace_updated = False
    if with_marketplace:
        marketplace_target = (
            marketplace_path.expanduser() if marketplace_path else _default_marketplace_path(target_dir)
        )

    if not dry_run and not skipped:
        target_dir.parent.mkdir(parents=True, exist_ok=True)
        if target_dir.exists() and force:
            shutil.rmtree(target_dir)
        shutil.copytree(src, target_dir)
        manifest = {
            "managed_by": "mstack",
            "plugin": CODEX_PLUGIN_NAME,
            "target_dir": str(target_dir),
            "version": _installed_package_version(),
        }
        (target_dir / CODEX_PLUGIN_MANIFEST).write_text(
            json.dumps(manifest, indent=2),
            encoding="utf-8",
        )
        if with_marketplace and marketplace_target:
            marketplace_updated = _write_marketplace_entry(marketplace_target, target_dir)
    elif dry_run and with_marketplace and marketplace_target and not skipped:
        marketplace_updated = True

    return CodexPluginInstallResult(
        target_dir=target_dir,
        plugin_name=CODEX_PLUGIN_NAME,
        skill_count=skill_count,
        installed=not skipped,
        skipped=skipped,
        overwritten=overwritten,
        marketplace_path=marketplace_target,
        marketplace_updated=marketplace_updated,
    )


def _is_managed_codex_skill(path: Path) -> bool:
    """Return True when the destination looks like a managed MStack skill."""
    if not path.is_dir():
        return False
    return (path / CODEX_MANIFEST).exists()


def _is_managed_codex_plugin(path: Path) -> bool:
    """Return True when the destination looks like a managed MStack plugin."""
    if not path.is_dir():
        return False
    return (path / CODEX_PLUGIN_MANIFEST).exists()


def _default_marketplace_path(target_dir: Path) -> Path:
    """Infer the repo-local marketplace path for a plugin target."""
    if target_dir.parent.name == "plugins":
        repo_root = target_dir.parent.parent
    else:
        repo_root = target_dir.parent
    return repo_root / ".agents" / "plugins" / "marketplace.json"


def _write_marketplace_entry(marketplace_path: Path, plugin_target: Path) -> bool:
    """Create or update a repo-local marketplace entry for the plugin."""
    marketplace_path.parent.mkdir(parents=True, exist_ok=True)
    repo_root = marketplace_path.parent.parent.parent
    relative_path = os.path.relpath(plugin_target, repo_root).replace("\\", "/")
    if not relative_path.startswith("."):
        relative_path = f"./{relative_path}"

    entry = {
        "name": CODEX_PLUGIN_NAME,
        "source": {
            "source": "local",
            "path": relative_path,
        },
        "policy": {
            "installation": "AVAILABLE",
            "authentication": "ON_INSTALL",
        },
        "category": "Productivity",
    }
    data = _load_marketplace_data(marketplace_path)
    data.setdefault("name", "local-marketplace")
    data.setdefault("interface", {"displayName": "Local Plugins"})
    plugins = data.setdefault("plugins", [])
    plugins = [item for item in plugins if item.get("name") != CODEX_PLUGIN_NAME]
    plugins.append(entry)
    data["plugins"] = sorted(plugins, key=lambda item: item["name"])
    marketplace_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return True


def _load_marketplace_data(marketplace_path: Path) -> dict[str, Any]:
    """Load marketplace data or return the packaged template."""
    if marketplace_path.exists():
        return json.loads(marketplace_path.read_text(encoding="utf-8"))

    template_path = asset_dir(PLUGIN_DIR) / PLUGIN_MARKETPLACE_TEMPLATE
    if template_path.exists():
        return json.loads(template_path.read_text(encoding="utf-8"))
    return {"plugins": []}


def _materialize_dir(resource: Traversable, name: str) -> Path:
    """Return a filesystem path for a resource directory, extracting if needed."""
    if isinstance(resource, Path):
        return resource

    cache_dir = Path(tempfile.gettempdir()) / "mstack-assets" / _installed_package_version() / name
    if cache_dir.exists():
        return cache_dir

    _copy_traversable_tree(resource, cache_dir)
    return cache_dir


def _copy_traversable_tree(source: Traversable, target: Path) -> None:
    """Copy a Traversable directory tree to a filesystem path."""
    target.mkdir(parents=True, exist_ok=True)
    for child in source.iterdir():
        child_target = target / child.name
        if child.is_dir():
            _copy_traversable_tree(child, child_target)
            continue
        child_target.write_bytes(child.read_bytes())


def _installed_package_version() -> str:
    """Return the installed package version for cache segregation."""
    try:
        return package_version("mstack")
    except PackageNotFoundError:
        return "dev"
