# Codex Word Style Identical Install Bundle

이 번들은 현재 컴퓨터에서 사용 중인 최신 Codex skill 구성을 다른 Windows 컴퓨터에 **동일하게** 설치하기 위한 패키지다.

포함 항목:

- `.codex/skills/word-style-upgrade`
- `.codex/skills/doc`

`word-style-upgrade`는 Word field/pagination/TOC 작업 시 `doc` skill의 가드레일을 전제로 하므로, 두 skill을 함께 설치해야 현재와 같은 동작이 난다.

## 설치 방법

### 방법 1. PowerShell 스크립트 사용

PowerShell에서 bundle root로 이동한 뒤 실행:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install.ps1
```

기본 설치 위치:

```text
%USERPROFILE%\.codex\skills\
```

### 방법 2. 수동 복사

아래 두 폴더를 대상 컴퓨터의 `%USERPROFILE%\.codex\skills\` 아래로 그대로 복사:

- `.codex\skills\word-style-upgrade`
- `.codex\skills\doc`

예:

```powershell
New-Item -ItemType Directory -Path "$HOME\.codex\skills" -Force
Copy-Item -LiteralPath ".\.codex\skills\word-style-upgrade" -Destination "$HOME\.codex\skills\word-style-upgrade" -Recurse
Copy-Item -LiteralPath ".\.codex\skills\doc" -Destination "$HOME\.codex\skills\doc" -Recurse
```

## 설치 후

- Codex를 완전히 종료 후 다시 시작
- 새 세션에서 `Use $word-style-upgrade ...`로 호출

## 검증 포인트

- `%USERPROFILE%\.codex\skills\word-style-upgrade\SKILL.md` 존재
- `%USERPROFILE%\.codex\skills\doc\SKILL.md` 존재
- `word-style-upgrade`의 `Trusted source selection`, `Document class split`, `Saved-file verification gate` 문단 존재
- `doc`의 `Word automation` guardrail 문단 존재
