$ErrorActionPreference = 'Stop'

$bundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceRoot = Join-Path $bundleRoot '.codex\skills'
$targetRoot = Join-Path $HOME '.codex\skills'

Write-Host "Bundle root: $bundleRoot"
Write-Host "Target root: $targetRoot"

if (-not (Test-Path $sourceRoot)) {
    throw "Source skills directory not found: $sourceRoot"
}

New-Item -ItemType Directory -Path $targetRoot -Force | Out-Null

$skills = @('word-style-upgrade', 'doc')
foreach ($skill in $skills) {
    $src = Join-Path $sourceRoot $skill
    $dst = Join-Path $targetRoot $skill
    if (-not (Test-Path $src)) {
        throw "Missing bundled skill: $src"
    }
    if (Test-Path $dst) {
        Remove-Item -LiteralPath $dst -Recurse -Force
    }
    Copy-Item -LiteralPath $src -Destination $dst -Recurse
    Write-Host "Installed: $skill"
}

Write-Host ""
Write-Host "Installation complete."
Write-Host "Restart Codex to pick up new skills."
