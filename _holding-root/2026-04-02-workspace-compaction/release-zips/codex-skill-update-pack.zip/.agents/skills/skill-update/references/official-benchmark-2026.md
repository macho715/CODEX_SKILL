# Official benchmark notes for skill-update

Verification date: 2026-04-02  
Source policy: official OpenAI docs only for behavior, paths, orchestration, and model guidance.

## Confirmed 2026 facts to apply

1. **Codex skill locations**
   - Repo search path: `.agents/skills` from current working directory up to repo root
   - User path: `$HOME/.agents/skills`
   - Admin path: `/etc/codex/skills`
   - Skills are not merged by name; both can appear in selectors if names collide.

2. **Codex instruction loading**
   - Codex reads `AGENTS.md` before work.
   - Global scope prefers `~/.codex/AGENTS.override.md`, otherwise `~/.codex/AGENTS.md`.
   - Project scope walks from project root to current directory and checks `AGENTS.override.md`, then `AGENTS.md`.

3. **Custom agents**
   - Project path: `.codex/agents/`
   - User path: `~/.codex/agents/`
   - Required fields: `name`, `description`, `developer_instructions`
   - Useful inherited optional fields: `model`, `sandbox_mode`, `skills.config`

4. **Subagent threading defaults**
   - `agents.max_threads` default is 6
   - `agents.max_depth` default is 1
   - Deep recursive fan-out should stay exceptional

5. **Model routing**
   - Start with `gpt-5.4` for most Codex work
   - Use `gpt-5.4-mini` for fast, lower-cost subagents

6. **Multi-agent orchestration**
   - Agents SDK supports handoffs and agents-as-tools
   - Use handoffs when a specialist should own the rest of the turn
   - Use agents-as-tools when a manager should keep control of the final answer
   - Parallel work can be done in code, for example with `Promise.all`

7. **Skill evaluation**
   - A useful eval asks:
     - Did the agent invoke the skill?
     - Did it run expected commands?
     - Did it produce the expected output conventions?

## How skill-update uses this

- repo skill scan honors official Codex paths
- AGENTS.md is always read before patching skill files
- parallel-first behavior prefers custom agents when installed
- verification report must downgrade honestly if runtime support is missing
- model routing defaults to gpt-5.4 manager + gpt-5.4-mini scouts
