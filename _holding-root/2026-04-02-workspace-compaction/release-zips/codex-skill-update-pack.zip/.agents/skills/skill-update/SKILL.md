---
name: skill-update
description: Update or create Codex skills with a parallel-first workflow. Use when you need to benchmark a skill against the latest official docs, detect related existing skills and processes, reuse compatible assets, and produce validated skill patches or a new skill package.
---

# Skill Update

## Purpose

Use this skill to update an existing Codex skill or create a new one while preserving reuse, enforcing a parallel-first workflow, and grounding decisions in the latest official OpenAI skill and multi-agent guidance.

This skill is for:
- updating a stale skill against current Codex behavior
- creating a new skill that must interoperate with existing skills
- benchmarking a skill workflow against official 2026+ docs
- preparing a plugin-ready or CI-ready skill package

This skill is **not** for:
- destructive repo-wide rewrites without approval
- inventing undocumented Codex features
- claiming parallel execution is guaranteed when the runtime does not expose subagents or orchestration support

## Inputs

Minimum useful input:
- target skill name
- create or update intent
- repository root or working directory
- constraints: internet allowed or blocked, approval policy, destructive actions allowed or not
- optional: exact output paths, target model, plugin packaging target

Recommended input contract:
```json
{
  "mode": "create|update",
  "target_skill": "skill-name",
  "repo_root": ".",
  "intent": "one sentence goal",
  "internet_allowed": true,
  "allow_destructive": false,
  "emit_optional_agents": true,
  "notes": "optional constraints"
}
```

## Output Contract

Always produce these artifacts:

1. `artifacts/skill_inventory.json`
   - discovered skills, locations, descriptions, scripts, related keywords, possible overlaps

2. `artifacts/update_plan.json`
   - recommended reuse paths, touched files, integration points, risks, required approvals

3. Updated or newly created skill package under the requested path

4. `artifacts/verification_report.md`
   - validation checks, missing data, blocked items, next actions

5. `artifacts/benchmark_notes.md`
   - official-doc benchmark summary with absolute dates

## Parallel-First Policy

Default policy: **parallel-first**.

When the runtime supports Codex subagents or external orchestration, split the work into at least 3 concurrent lanes:

- **Lane A — Inventory / Reuse Scout**
  - discover existing skills and related scripts
  - inspect AGENTS.md layers and repo conventions
  - find overlap, duplication, and integration hooks

- **Lane B — Official Docs Scout**
  - inspect the latest official documentation relevant to skills, AGENTS.md, custom agents, models, Agents SDK, and changelog
  - collect only source-backed changes that affect behavior or packaging

- **Lane C — Author / Patch Worker**
  - draft the new skill or patch the existing one
  - wire reuse links to existing skills/processes
  - update references and examples

Optional fourth lane when available:

- **Lane D — Verifier**
  - validate frontmatter, file layout, integration claims, dry-run outputs, and report completeness

### Runtime rule

- If Codex custom agents are installed, prefer them.
- Otherwise use built-in `explorer` for discovery and `worker` for authoring.
- If neither subagents nor orchestration are available, continue with the same procedure but mark the run as `PARALLEL_DEGRADED` in the verification report. Do not pretend full parallel enforcement happened.

## Procedure

### Step 0 — Preflight and safety

1. Read active `AGENTS.md` guidance first.
2. Confirm whether internet access is allowed.
3. Confirm whether destructive changes are allowed.
4. For destructive actions, require:
   - dry-run
   - change list
   - explicit approval
5. Load this skill's local references before browsing external docs.

### Step 1 — Discover existing skills and linked processes

Run:
```bash
python .agents/skills/skill-update/scripts/scan_skill_graph.py --root . --write artifacts/skill_inventory.json
```

What to detect:
- `.agents/skills` from current directory upward to repo root
- `$HOME/.agents/skills`
- `/etc/codex/skills` if readable
- related `AGENTS.md` or `AGENTS.override.md`
- nearby scripts, references, assets, agents, CI workflows
- reused command names, shared keywords, repeated sections, duplicate responsibilities

Reuse rules:
- prefer updating a compatible existing skill over creating a duplicate
- if two skills overlap, propose merge, split, or precedence
- if a process already exists in `scripts/` or CI, reuse it instead of re-describing it

### Step 2 — Benchmark against latest official docs

If internet is allowed:
- open current official OpenAI docs for:
  - Codex skills
  - AGENTS.md
  - Codex subagents
  - Codex models
  - Codex + Agents SDK
  - Agent Skills eval guidance
- summarize only changes that affect:
  - file paths
  - scan precedence
  - model routing
  - orchestration pattern
  - validation strategy
  - plugin packaging
- write absolute dates in `artifacts/benchmark_notes.md`

If internet is blocked:
- use `references/official-benchmark-2026.md`
- mark `WEB_BLOCKED` in outputs

### Step 3 — Plan integration

Run:
```bash
python .agents/skills/skill-update/scripts/build_update_plan.py \
  --request .agents/skills/skill-update/examples/request.example.json \
  --inventory artifacts/skill_inventory.json \
  --write artifacts/update_plan.json
```

Planning rules:
- preserve working scripts unless the update plan explicitly replaces them
- avoid copying long policy text into `SKILL.md` when it belongs in `references/`
- keep one skill = one responsibility
- if a related process already exists, link it and explain why it is reused
- if optional custom agents are available, map each lane to one agent

### Step 4 — Author or patch the skill

Required skill structure:
```text
<skill-name>/
  SKILL.md
  scripts/
  references/
  examples/
```

Authoring rules:
- `name` must match the folder name
- `description` must say what the skill does and when to use it
- keep the main `SKILL.md` concise and operational
- push long references, benchmark notes, and templates into `references/`
- prefer deterministic helper scripts for scanning, validation, and report generation

### Step 5 — Validate

Run:
```bash
python .agents/skills/skill-update/scripts/validate_outputs.py \
  --skill-root <target-skill-root> \
  --inventory artifacts/skill_inventory.json \
  --plan artifacts/update_plan.json \
  --write artifacts/verification_report.md
```

Validation checks:
- frontmatter exists and matches folder name
- description is specific enough to trigger correctly
- required sections exist
- integration claims point to real files or are marked assumptions
- no destructive step lacks a dry-run gate
- outputs promised by the skill are actually present

### Step 6 — Package and report

Deliver:
- final file tree
- changed files
- reused skills and processes
- benchmark notes with dates
- validation status:
  - PASS
  - PASS_WITH_WARNINGS
  - PARALLEL_DEGRADED
  - BLOCKED

## Model Routing Guidance

When the runtime allows model selection:
- use `gpt-5.4` for the manager / author / verifier path
- use `gpt-5.4-mini` for fast scout subagents and lightweight discovery

If your environment only exposes one model, continue and record the limitation.

## Additional Ideas to Apply Automatically

When relevant, add these improvements:

1. **Skill graph manifest**
   - emit a reusable inventory JSON that future skills can consume

2. **Description optimizer**
   - rewrite weak `description` fields so Codex can route more reliably

3. **Overlap detector**
   - flag duplicate skills with near-identical triggers or outputs

4. **Eval stub generation**
   - generate a small checklist or eval dataset for future regression testing

5. **Plugin-ready packaging**
   - if the skill may be shared outside one repo, propose a plugin-ready structure

6. **Model-aware orchestration**
   - route deep synthesis to `gpt-5.4`, scout tasks to `gpt-5.4-mini`

7. **Changelog note**
   - add a compact `what changed and why` section for each update

## Failure Modes

Use these exact labels:
- `WEB_BLOCKED`: network unavailable, used bundled references
- `PARALLEL_DEGRADED`: no usable subagents/orchestrator, sequential fallback used
- `INVENTORY_INCOMPLETE`: skill scan could not reach all configured locations
- `VALIDATION_FAILED`: required checks did not pass
- `APPROVAL_REQUIRED`: destructive action requested but not approved

## Safety

- Never expose secrets, tokens, internal URLs, or private repo identifiers in benchmark notes
- Never claim a feature exists without a source-backed official doc or a real local file
- Never delete or overwrite an existing skill without dry-run + explicit approval
- When unsure, preserve current files and emit a patch plan instead of forcing a rewrite
