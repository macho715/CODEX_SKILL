---
name: orchestrate-analysis
description: Break a complex task into a planner plus 2-4 specialist workstreams and a final verifier pass. Use when the user asks for multi-perspective analysis, system design, strategy options, or decision support that must be structured, checkable, and reproducible.
---

# Orchestrate Analysis

## When to use
Use this skill when:
- the user wants a planner + specialist + verifier workflow,
- multiple viewpoints must be covered before a recommendation,
- a draft answer needs stronger structure and traceability.

Do not use this skill when:
- the task is a one-shot factual lookup,
- there is only one narrow perspective,
- the user only wants a short chat reply with no structure.

## Inputs
- Goal or decision to make
- Constraints, risks, and non-negotiables
- Required specialist lanes (if the user specified them)
- Available evidence, data, links, or files
- Output format required by the user

## Specialist lane defaults
If the user did not define lanes, start with:
- Cost / ROI
- Risk / Compliance
- Operations / Logistics / Execution

You may swap these for other lanes if the task clearly calls for different expertise.

## Procedure

### 1. Planner phase
Create a compact execution plan with:
- objective,
- success criteria,
- lane definitions,
- what can run in parallel,
- what the verifier must check.

### 2. Specialist phase
Ask each lane to produce only:
- its scope,
- key findings,
- assumptions,
- evidence gaps,
- 1-3 concrete recommendations.

Keep the lanes independent. Do not let one lane rewrite another lane.

### 3. Merge phase
Build one merged draft that contains:
- common facts,
- lane-specific findings,
- contradictions,
- open questions,
- candidate options.

### 4. Verifier handoff
Pass the merged draft to `analysis-verifier` or apply the same rubric manually.
The verifier must test all required acceptance criteria before the final answer is emitted.

### 5. Replan gate
If the verifier returns FAIL:
- replan once,
- patch only failed sections,
- do not restart the whole workflow unless the user explicitly asks.

Maximum replan count: 1.

### 6. Final output contract
Return a structured final answer with these sections in order:
1. Executive summary
2. Planner summary
3. Specialist findings
4. Verifier verdict
5. Final recommendation
6. Assumptions and evidence gaps

## Output rules
- Mark unsupported statements as assumptions.
- Keep the final answer reproducible: show criteria, not only conclusions.
- When options are comparable, call `scenario-scorer` for deterministic ranking.

## Safety
- No destructive actions without dry-run, change list, and approval.
- No fabricated evidence.
- If critical inputs are missing, stop and request the minimum missing inputs.

## References
- See `references/output-contract.md` for the default section layout and pass criteria.
