---
name: analysis-verifier
description: Validate a draft analysis, workflow design, or multi-agent output against explicit acceptance criteria. Use after a draft claims completion and you need PASS/FAIL separation, gap detection, and a minimal patch list.
---

# Analysis Verifier

## When to use
Use this skill when:
- a planner-specialist draft already exists,
- the user asks whether the draft is complete,
- a multi-agent output needs an independent skeptical review.

Do not use this skill when:
- nothing has been drafted yet,
- the task is pure brainstorming without acceptance criteria.

## Inputs
- Draft output to verify
- Acceptance criteria or checklist
- Optional source files, links, or evidence references

## Verification procedure

### 1. Extract claims
List what the draft claims to have completed.

### 2. Map claims to checks
Map each claim to a concrete verification point.

### 3. Apply the default checklist
When no custom checklist is supplied, verify these five items:
1. Planner-first structure exists.
2. All required specialists responded at least once.
3. Verifier output separates PASS and FAIL.
4. Replan loop is capped at one.
5. Final output is structured and reproducible.

### 4. Produce a strict verdict
Use this exact logic:
- PASS: requirement satisfied and evidence is visible.
- FAIL: requirement missing, ambiguous, or contradicted.
- AMBER: partially satisfied but evidence is weak.

### 5. Patch guidance
If any item is FAIL or AMBER, provide only:
- failed item,
- reason,
- minimum patch needed,
- whether full rewrite is unnecessary.

## Output format
Return a compact table or bullet set with:
- Check
- Status (PASS / FAIL / AMBER)
- Evidence
- Required patch

Then finish with:
- Overall verdict
- Replan needed? (Yes/No)
- Safe to finalize? (Yes/No)

## Safety
- Be skeptical.
- Do not reward style when evidence is missing.
- Do not rewrite the whole draft unless the user asks.

## References
- See `references/default-checklist.md` for the default acceptance rubric.
