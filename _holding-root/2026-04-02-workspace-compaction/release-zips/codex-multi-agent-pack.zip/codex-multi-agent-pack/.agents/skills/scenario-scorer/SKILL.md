---
name: scenario-scorer
description: Rank 3 or more options with explicit criteria and deterministic weights. Use when strategies, scenarios, or implementation options must be scored reproducibly instead of chosen by narrative preference.
---

# Scenario Scorer

## When to use
Use this skill when:
- there are 3 or more options,
- the user wants a recommendation with explicit weights,
- the final choice should be reproducible by calculation.

Do not use this skill when:
- there is only one option,
- weights or criteria are unavailable and cannot be reasonably proposed,
- the user only wants qualitative brainstorming.

## Inputs
- Options list
- Criteria list
- Weight per criterion
- Score scale (default: 1-5)
- Optional rationale per score

## Deterministic workflow
1. Confirm options and criteria.
2. Confirm weights sum to 100.
3. Score each option on each criterion.
4. Run `scripts/score_options.py` when possible.
5. Present total score, ranking, and key trade-offs.

## Default criteria
If the user did not provide criteria, propose:
- Impact
- Feasibility
- Risk
- Time-to-value

## Output format
Return:
- scoring table,
- ranked options,
- recommended option,
- sensitivity note if one criterion dominates the outcome.

## Safety
- Keep scoring rules visible.
- Do not hide assumptions.
- If weights are arbitrary, say so.

## References
- Example inputs and outputs live in `examples/`.
- Weighting tips live in `references/weighting-guide.md`.
