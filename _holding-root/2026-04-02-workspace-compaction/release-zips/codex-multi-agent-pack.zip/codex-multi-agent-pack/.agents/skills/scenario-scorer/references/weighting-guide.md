# Weighting Guide

## Recommended defaults
- Impact: 35
- Feasibility: 25
- Risk: 20
- Time-to-value: 20

## Good practice
- Keep the weight total at 100.
- Prefer 4-6 criteria.
- Keep the score scale fixed across options.
- Note whether a high score means high risk is good or bad; convert the scale if needed before scoring.

## Sensitivity note
If the top option wins by less than 5.00 points, report the result as close and mention which criterion would most likely flip the ranking.
